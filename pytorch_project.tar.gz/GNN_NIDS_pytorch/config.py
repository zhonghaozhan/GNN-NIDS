import os

class Config:
    # Get the absolute base directory
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # Paths
    TRAIN_PATH = os.path.join(BASE_DIR, 'preprocess_dataset/preprocessed_IDS2017/TRAIN')
    VAL_PATH = os.path.join(BASE_DIR, 'preprocess_dataset/preprocessed_IDS2017/EVAL')
    LOG_DIR = os.path.join(BASE_DIR, 'GNN_NIDS_pytorch/logs')
    CHECKPOINT_DIR = os.path.join(BASE_DIR, 'GNN_NIDS_pytorch/checkpoints')

    # Model parameters
    NODE_STATE_DIM = 128
    NUM_LAYERS = 8  # equivalent to 't' in TF version
    INPUT_DIM = 84  # Updated feature dimension based on the CSV data
    OUTPUT_DIM = 16  # Number of classes (updated based on unique labels)
    HIDDEN_DIM = 128
    DROPOUT = 0.5

    # Training parameters
    BATCH_SIZE = 32
    LEARNING_RATE = 0.001
    NUM_EPOCHS = 100
    WEIGHT_DECAY = 0.1  # L2 regularization
    
    # Early stopping
    PATIENCE = 10
    
    # Device configuration
    DEVICE = 'cpu'  # Will be updated to 'cuda' if available
