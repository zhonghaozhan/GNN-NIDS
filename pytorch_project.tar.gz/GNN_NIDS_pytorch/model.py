import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops

class GNNLayer(MessagePassing):
    def __init__(self, node_state_dim, dropout=0.5):
        super(GNNLayer, self).__init__(aggr='mean')  # Using mean aggregation
        self.node_state_dim = node_state_dim
        
        # Message functions
        self.message_nn = nn.Sequential(
            nn.Linear(node_state_dim * 2, node_state_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Update function
        self.gru = nn.GRUCell(node_state_dim, node_state_dim)

    def forward(self, x, edge_index):
        # Add self-loops to the adjacency matrix
        edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))
        
        # Start propagating messages
        return self.propagate(edge_index, x=x)

    def message(self, x_i, x_j):
        # Construct messages from source nodes x_j to target nodes x_i
        tmp = torch.cat([x_i, x_j], dim=1)  # Concatenate states
        return self.message_nn(tmp)

    def update(self, aggr_out, x):
        # Update node embeddings
        return self.gru(aggr_out, x)

class GNN(nn.Module):
    def __init__(self, config):
        super(GNN, self).__init__()
        
        self.input_dim = config.INPUT_DIM
        self.hidden_dim = config.NODE_STATE_DIM
        self.output_dim = config.OUTPUT_DIM
        self.num_layers = config.NUM_LAYERS
        self.dropout = config.DROPOUT

        # Initial feature transformation with batch normalization
        self.input_transform = nn.Sequential(
            nn.Linear(self.input_dim, self.hidden_dim),
            nn.BatchNorm1d(self.hidden_dim),
            nn.ReLU(),
            nn.Dropout(self.dropout)
        )
        
        # GNN layers
        self.gnn_layers = nn.ModuleList([
            GNNLayer(self.hidden_dim, self.dropout)
            for _ in range(self.num_layers)
        ])
        
        # Layer normalization after each GNN layer
        self.layer_norms = nn.ModuleList([
            nn.LayerNorm(self.hidden_dim)
            for _ in range(self.num_layers)
        ])
        
        # Readout network
        self.readout = nn.Sequential(
            nn.Linear(self.hidden_dim, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(self.dropout),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(self.dropout),
            nn.Linear(128, self.output_dim)
        )

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        
        # Initial feature transformation
        x = self.input_transform(x)
        
        # Message passing layers with residual connections and layer normalization
        for gnn, norm in zip(self.gnn_layers, self.layer_norms):
            # Store the input for residual connection
            identity = x
            
            # Apply GNN layer
            x = gnn(x, edge_index)
            
            # Apply layer normalization
            x = norm(x)
            
            # Add residual connection
            x = x + identity
            
            # Apply non-linearity
            x = F.relu(x)
        
        # Apply readout network
        x = self.readout(x)
        
        # Apply log softmax for numerical stability
        return F.log_softmax(x, dim=1)

    def reset_parameters(self):
        """Reset all learnable parameters of the model."""
        def _reset(m):
            if hasattr(m, 'reset_parameters'):
                m.reset_parameters()
        
        self.apply(_reset)
